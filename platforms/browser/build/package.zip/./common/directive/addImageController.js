(function () {
    'use strict';
    angular
        .module('myApp')
        .controller('addImageController',
                    ['$scope','settings', addImageController]);

function addImageController ($scope,settings) {

	var imgCtrl = this;
        
};
}());